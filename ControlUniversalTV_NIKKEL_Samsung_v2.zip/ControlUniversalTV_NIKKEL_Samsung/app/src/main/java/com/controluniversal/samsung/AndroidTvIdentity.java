package com.controluniversal.samsung;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.math.BigInteger;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedKeyManager;
import javax.net.ssl.X509TrustManager;
import javax.security.auth.x500.X500Principal;
import java.net.Socket;
import javax.net.ssl.SSLEngine;

/** Keeps one private client RSA identity in Android Keystore across app sessions. */
final class AndroidTvIdentity {
    private static final String ALIAS = "controluniversal_atv_v2";
    final X509Certificate cert;
    final SSLContext tls;

    AndroidTvIdentity() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            long now=System.currentTimeMillis();
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_DECRYPT)
                    .setKeySize(2048)
                    .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
                    .setCertificateSubject(new X500Principal("CN=ControlUniversalTV"))
                    .setCertificateSerialNumber(BigInteger.valueOf(now))
                    .setCertificateNotBefore(new Date(now-86400000L))
                    .setCertificateNotAfter(new Date(now+15L*365*86400000L))
                    .build());
            generator.generateKeyPair();
        }
        cert=(X509Certificate)store.getCertificate(ALIAS);
        PrivateKey privateKey=(PrivateKey)store.getKey(ALIAS,null);
        if(cert==null || privateKey==null)throw new IllegalStateException("Identidad Android TV no disponible");
        final X509Certificate[] chain={cert};
        final PrivateKey pk=privateKey;
        KeyManager manager=new X509ExtendedKeyManager() {
            @Override public String[] getClientAliases(String keyType, java.security.Principal[] issuers) {
                return "RSA".equalsIgnoreCase(keyType)?new String[]{ALIAS}:null;
            }
            @Override public String chooseClientAlias(String[] types, java.security.Principal[] issuers,Socket socket){
                for(String t:types) if("RSA".equalsIgnoreCase(t))return ALIAS;
                return null;
            }
            @Override public String chooseEngineClientAlias(String[] types,java.security.Principal[] issuers,SSLEngine engine){
                return chooseClientAlias(types,issuers,null);
            }
            @Override public String[] getServerAliases(String type,java.security.Principal[] issuers){return null;}
            @Override public String chooseServerAlias(String type,java.security.Principal[] issuers,Socket socket){return null;}
            @Override public String chooseEngineServerAlias(String type,java.security.Principal[] issuers,SSLEngine engine){return null;}
            @Override public X509Certificate[] getCertificateChain(String alias){return ALIAS.equals(alias)?chain:null;}
            @Override public PrivateKey getPrivateKey(String alias){return ALIAS.equals(alias)?pk:null;}
        };
        // TVs have self-signed certificates. Trust is established by the pairing proof,
        // then the TV certificate is SHA-256 pinned for subsequent remote sessions.
        TrustManager trust=new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] c,String a) { }
            @Override public void checkServerTrusted(X509Certificate[] c,String a) { }
            @Override public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
        };
        tls=SSLContext.getInstance("TLS");
        tls.init(new KeyManager[]{manager},new TrustManager[]{trust},new SecureRandom());
    }
}
