package com.controluniversal.samsung;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;

/** Android TV Remote Service v2 / Polo: no cloud and no ADB required.
 * Designed for Android TV / Google TV, NOT all televisions sold as Smart TV.
 * All methods that open sockets or exchange data must be called off the UI thread.
 */
public final class AndroidTvRemote implements Closeable {
    public interface Events {
        void status(String state, String text);
        void enterCode();
        void connected();
        void lost(String reason);
    }

    private final String host;
    private final SSLContext tls;
    private final X509Certificate clientCertificate;
    private final Events events;
    private final Object writeLock = new Object();
    private volatile boolean closed = false;
    private volatile boolean ready = false;
    private volatile SSLSocket pairSocket;
    private volatile SSLSocket remoteSocket;
    private volatile String pairedFingerprint = "";
    private volatile String peerFingerprint = "";

    public AndroidTvRemote(String host, SSLContext tls, X509Certificate clientCertificate, Events events) {
        this.host = host;
        this.tls = tls;
        this.clientCertificate = clientCertificate;
        this.events = events;
    }

    public boolean isReady() { return ready; }
    public String pairingFingerprint() { return pairedFingerprint; }

    /** Reconnect only if the presented TV certificate matches the previously paired TV. */
    public void connectPreviouslyPaired(String pinnedFingerprint) throws Exception {
        if (pinnedFingerprint == null || pinnedFingerprint.isEmpty()) throw new SecurityException("Televisor no vinculado");
        openRemote(pinnedFingerprint);
    }

    public void beginPairing() throws Exception {
        events.status("pairing", "Solicitando código de vinculación en el televisor…");
        SSLSocket socket = open(6467);
        pairSocket = socket;
        write(socket, Proto.message(10, Proto.concat(Proto.string(1, "atvremote"),
                Proto.string(2, "Control Universal TV"))), true);
        boolean gotConfig = false;
        for (int i = 0; i < 8 && !gotConfig; i++) {
            Map<Integer, Proto.Field> response = Proto.parse(Proto.readFrame(socket.getInputStream()));
            verifyStatus(response);
            if (response.containsKey(11)) { // pairing_request_ack
                byte[] encoding = Proto.concat(Proto.number(1, 3), Proto.number(2, 6));
                write(socket, Proto.message(20, Proto.concat(Proto.message(1, encoding), Proto.number(3, 1))), true);
            } else if (response.containsKey(20)) { // TV options
                byte[] encoding = Proto.concat(Proto.number(1, 3), Proto.number(2, 6));
                write(socket, Proto.message(30, Proto.concat(Proto.message(1, encoding), Proto.number(2, 1))), true);
            } else if (response.containsKey(31)) { // configuration_ack
                gotConfig = true;
            } else {
                throw new IOException("La TV no completó la negociación de vinculación");
            }
        }
        if (!gotConfig) throw new IOException("No se recibió confirmación del televisor");
        socket.setSoTimeout(120000);
        events.enterCode();
    }

    public void finishPairing(String enteredCode) throws Exception {
        SSLSocket socket = pairSocket;
        if (socket == null || closed) throw new IOException("Inicia primero la vinculación");
        String code = enteredCode == null ? "" : enteredCode.trim().toUpperCase(java.util.Locale.ROOT);
        if (!code.matches("[0-9A-F]{6}")) throw new IllegalArgumentException("El código debe tener 6 caracteres, números o A-F");
        byte[] proof = makeProof(clientCertificate,
                (X509Certificate) socket.getSession().getPeerCertificates()[0], code);
        write(socket, Proto.message(40, Proto.message(1, proof)), true);
        Map<Integer, Proto.Field> response = Proto.parse(Proto.readFrame(socket.getInputStream()));
        verifyStatus(response);
        if (!response.containsKey(41)) throw new SecurityException("El televisor rechazó el código");
        pairedFingerprint = peerFingerprint;
        socket.close();
        pairSocket = null;
        events.status("connecting", "Código aceptado. Iniciando el control…");
        openRemote(pairedFingerprint);
    }

    /** Remote v2 uses a different TLS connection from the pairing channel. */
    private void openRemote(String pinnedFingerprint) throws Exception {
        SSLSocket socket = open(6466);
        remoteSocket = socket;
        try {
            if (!pinnedFingerprint.equals(peerFingerprint))
                throw new SecurityException("Cambió el certificado del televisor. Restablece el vínculo antes de continuar.");
            boolean started = false;
            for (int i = 0; i < 24 && !started && !closed; i++) {
                Map<Integer, Proto.Field> message = Proto.parse(Proto.readFrame(socket.getInputStream()));
                started = handleRemote(message);
            }
            if (!started || closed) throw new IOException("La TV no activó el servicio de control remoto");
            ready = true;
            socket.setSoTimeout(0);
            events.connected();
        } catch (Exception e) {
            try { socket.close(); } catch (Exception ignored) { }
            remoteSocket = null;
            throw e;
        }
    }

    public void runReader() {
        SSLSocket socket = remoteSocket;
        if (socket == null) return;
        try {
            while (ready && !closed) handleRemote(Proto.parse(Proto.readFrame(socket.getInputStream())));
        } catch (Exception e) {
            if (!closed) {
                ready = false;
                events.lost(e.getMessage() == null ? "Conexión interrumpida" : e.getMessage());
            }
        } finally { try { socket.close(); } catch (IOException ignored) { } }
    }

    private boolean handleRemote(Map<Integer, Proto.Field> data) throws Exception {
        if (data.containsKey(1)) {
            byte[] info = Proto.concat(Proto.number(3, 1), Proto.string(4, "1"),
                    Proto.string(5, "com.controluniversal.samsung"), Proto.string(6, "2.0"));
            // PING | KEY | POWER | VOLUME | APP_LINK
            sendRemote(Proto.message(1, Proto.concat(Proto.number(1, 611), Proto.message(2, info))));
        }
        if (data.containsKey(2)) sendRemote(Proto.message(2, Proto.number(1, 611)));
        if (data.containsKey(8)) {
            Map<Integer, Proto.Field> ping = Proto.parse(data.get(8).bytes);
            long value = Proto.longValue(ping, 1);
            sendRemote(Proto.message(9, Proto.number(1, value)));
        }
        if (data.containsKey(3)) throw new IOException("El televisor notificó un error de protocolo");
        return data.containsKey(40);
    }

    public void sendKey(int code) throws Exception {
        if (!ready || remoteSocket == null) throw new IOException("Primero conecta el televisor");
        sendRemote(Proto.message(10, Proto.concat(Proto.number(1, code), Proto.number(2, 3))));
    }

    public void sendAppLink(String url) throws Exception {
        if (!ready || remoteSocket == null) throw new IOException("Primero conecta el televisor");
        if (!("https://www.youtube.com".equals(url) || "https://www.netflix.com".equals(url)))
            throw new IllegalArgumentException("Destino no permitido");
        sendRemote(Proto.message(90, Proto.string(1, url)));
    }

    private SSLSocket open(int port) throws Exception {
        if (closed) throw new IOException("Sesión cerrada");
        SSLSocket s = (SSLSocket) tls.getSocketFactory().createSocket();
        s.connect(new InetSocketAddress(host, port), 3500);
        s.setSoTimeout(8000);
        s.startHandshake();
        X509Certificate tvCert = (X509Certificate) s.getSession().getPeerCertificates()[0];
        peerFingerprint = hex(MessageDigest.getInstance("SHA-256").digest(tvCert.getEncoded()));
        return s;
    }

    private void write(SSLSocket s, byte[] nested, boolean polo) throws IOException {
        byte[] payload = polo ? Proto.concat(Proto.number(1, 2), Proto.number(2, 200), nested) : nested;
        synchronized (writeLock) { Proto.writeFrame(s.getOutputStream(), payload); }
    }
    private void sendRemote(byte[] payload) throws IOException {
        SSLSocket s = remoteSocket;
        if (s == null) throw new IOException("No hay conexión activa");
        synchronized (writeLock) { Proto.writeFrame(s.getOutputStream(), payload); }
    }
    private static void verifyStatus(Map<Integer, Proto.Field> message) throws IOException {
        long status = Proto.longValue(message, 2);
        if (status != 0 && status != 200) throw new IOException(status == 402 ?
                "Código de vinculación incorrecto" : "El televisor rechazó la vinculación (" + status + ")");
    }

    /** Proof binds the on-screen pairing code to *both* RSA public keys. */
    static byte[] makeProof(X509Certificate clientCert, X509Certificate tvCert, String code) throws Exception {
        RSAPublicKey client = (RSAPublicKey) clientCert.getPublicKey();
        RSAPublicKey tv = (RSAPublicKey) tvCert.getPublicKey();
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        for (BigInteger number : new BigInteger[]{client.getModulus(), client.getPublicExponent(),
                tv.getModulus(), tv.getPublicExponent()}) {
            byte[] b = number.toByteArray();
            sha.update(b.length > 1 && b[0] == 0 ? Arrays.copyOfRange(b, 1, b.length) : b);
        }
        for (int i = 2; i < 6; i += 2) sha.update((byte) Integer.parseInt(code.substring(i, i + 2), 16));
        byte[] result = sha.digest();
        if ((result[0] & 0xff) != Integer.parseInt(code.substring(0, 2), 16))
            throw new SecurityException("El código no corresponde a este televisor. Revisa los seis caracteres.");
        return result;
    }
    private static String hex(byte[] bytes) {
        StringBuilder s = new StringBuilder();
        for (byte b : bytes) s.append(String.format(java.util.Locale.ROOT, "%02x", b & 0xff));
        return s.toString();
    }
    @Override public void close() {
        closed = true; ready = false;
        try { if (pairSocket != null) pairSocket.close(); } catch (IOException ignored) { }
        try { if (remoteSocket != null) remoteSocket.close(); } catch (IOException ignored) { }
        pairSocket = null; remoteSocket = null;
    }

    /** Compact, hand-written protobuf framing. Supports the wire types used here. */
    static final class Proto {
        static final class Field { final long number; final byte[] bytes;
            Field(long number, byte[] bytes) { this.number = number; this.bytes = bytes; } }
        static byte[] concat(byte[]... chunks) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            for (byte[] chunk : chunks) b.write(chunk, 0, chunk.length);
            return b.toByteArray();
        }
        static byte[] v(long n) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            while ((n & ~127L) != 0) { b.write((int)((n & 127) | 128)); n >>>= 7; }
            b.write((int)n); return b.toByteArray();
        }
        static byte[] number(int field, long n) { return concat(v(field * 8L), v(n)); }
        static byte[] message(int field, byte[] bytes) {
            return concat(v(field * 8L + 2), v(bytes.length), bytes);
        }
        static byte[] string(int field, String value) {
            return message(field, value.getBytes(StandardCharsets.UTF_8));
        }
        static void writeFrame(OutputStream out, byte[] data) throws IOException {
            if (data.length > 1048576) throw new IOException("Mensaje excesivamente grande");
            out.write(v(data.length)); out.write(data); out.flush();
        }
        static byte[] readFrame(InputStream input) throws IOException {
            long len = readVarint(input);
            if (len < 0 || len > 1048576) throw new IOException("Trama de TV fuera de rango");
            byte[] b = new byte[(int)len];
            int offset = 0;
            while (offset < b.length) {
                int n = input.read(b, offset, b.length - offset);
                if (n < 0) throw new EOFException("Sesión terminada");
                offset += n;
            }
            return b;
        }
        static long readVarint(InputStream s) throws IOException {
            long n=0;
            for (int i=0;i<10;i++) {
                int b=s.read(); if(b<0)throw new EOFException("Trama incompleta");
                n |= (long)(b & 127) << (i*7);
                if ((b&128)==0)return n;
            }
            throw new IOException("Varint inválido");
        }
        static Map<Integer,Field> parse(byte[] raw) throws IOException {
            ByteArrayInputStream in = new ByteArrayInputStream(raw);
            Map<Integer,Field> fields = new LinkedHashMap<>();
            while (in.available()>0) {
                long tag=readVarint(in);
                int field=(int)(tag>>3), wire=(int)(tag&7);
                if (field<1 || field>50000) throw new IOException("Campo protobuf inválido");
                if (wire==0) fields.put(field, new Field(readVarint(in),null));
                else if(wire==2) {
                    long len=readVarint(in);
                    if(len<0 || len>in.available()) throw new IOException("Campo protobuf incompleto");
                    byte[] data=new byte[(int)len];
                    if(in.read(data)!=data.length && data.length!=0) throw new EOFException();
                    fields.put(field,new Field(0,data));
                } else if(wire==1 || wire==5) {
                    int size=wire==1?8:4;
                    if(in.skip(size)!=size) throw new EOFException();
                } else throw new IOException("Tipo protobuf no admitido: "+wire);
            }
            return fields;
        }
        static long longValue(Map<Integer,Field> fields,int n) {
            Field f=fields.get(n);return f==null ? 0 : f.number;
        }
    }
}
