package com.controluniversal.samsung;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.util.Base64;
import java.util.Locale;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

/**
 * Minimal RFC 6455 client for a private-LAN Samsung TV.
 * No third-party libraries. TLS uses TOFU certificate pinning, managed by the caller.
 */
public final class WebSocketTransport {
    public interface Listener {
        void onMessage(String json);
        void onClosed(String reason);
    }

    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;
    private final Listener listener;
    private final SecureRandom random = new SecureRandom();
    private final Object sendLock = new Object();
    private volatile boolean closed;
    private final String tlsFingerprint;

    private WebSocketTransport(Socket socket, Listener listener, String fingerprint) throws IOException {
        this.socket = socket;
        this.in = socket.getInputStream();
        this.out = socket.getOutputStream();
        this.listener = listener;
        this.tlsFingerprint = fingerprint;
    }

    public String getTlsFingerprint() { return tlsFingerprint; }

    public static WebSocketTransport open(String ip, int port, String path, String savedFingerprint,
                                          Listener listener) throws Exception {
        Socket base = new Socket();
        Socket active = null;
        String fingerprint = "";
        try {
            base.connect(new InetSocketAddress(ip, port), 3500);
            base.setSoTimeout(40000);
            base.setTcpNoDelay(true);
            if (port == 8002) {
                // Samsung TV endpoints commonly use locally issued certificates. The first
                // fingerprint is stored only after pairing; future connections must match.
                TrustManager[] firstUseTrust = { new X509TrustManager() {
                    public void checkClientTrusted(X509Certificate[] c, String a) { }
                    public void checkServerTrusted(X509Certificate[] c, String a) { }
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                }};
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, firstUseTrust, new SecureRandom());
                SSLSocket secure = (SSLSocket) ctx.getSocketFactory().createSocket(base, ip, port, true);
                secure.setSoTimeout(40000);
                secure.startHandshake();
                Certificate cert = secure.getSession().getPeerCertificates()[0];
                fingerprint = toHex(MessageDigest.getInstance("SHA-256").digest(cert.getEncoded()));
                if (savedFingerprint != null && !savedFingerprint.isEmpty()
                    && !MessageDigest.isEqual(savedFingerprint.getBytes(StandardCharsets.US_ASCII),
                                              fingerprint.getBytes(StandardCharsets.US_ASCII))) {
                    throw new SecurityException("El certificado del televisor cambió. Comprueba el equipo y restablece la vinculación.");
                }
                active = secure;
            } else {
                active = base;
            }
            WebSocketTransport ws = new WebSocketTransport(active, listener, fingerprint);
            ws.handshake(ip, port, path);
            return ws;
        } catch (Exception e) {
            if (active != null) try { active.close(); } catch (IOException ignored) { }
            try { base.close(); } catch (IOException ignored) { }
            throw e;
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder b = new StringBuilder(bytes.length * 2);
        for (byte x : bytes) b.append(String.format(Locale.ROOT, "%02x", x & 0xff));
        return b.toString();
    }

    private void handshake(String ip, int port, String path) throws Exception {
        byte[] keyBytes = new byte[16];
        random.nextBytes(keyBytes);
        String key = Base64.getEncoder().encodeToString(keyBytes);
        String request = "GET " + path + " HTTP/1.1\r\n"
                + "Host: " + ip + ":" + port + "\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Key: " + key + "\r\n"
                + "Sec-WebSocket-Version: 13\r\n"
                + "\r\n";
        out.write(request.getBytes(StandardCharsets.US_ASCII));
        out.flush();
        ByteArrayOutputStream header = new ByteArrayOutputStream();
        int a = 0, b = 0, c = 0, d;
        boolean finished = false;
        for (int n = 0; n < 16384; n++) {
            d = in.read();
            if (d < 0) throw new EOFException("El televisor cerró la conexión durante el enlace.");
            header.write(d);
            if (a == '\r' && b == '\n' && c == '\r' && d == '\n') { finished = true; break; }
            a = b; b = c; c = d;
        }
        if (!finished) throw new IOException("Respuesta WebSocket demasiado larga.");
        String response = header.toString("ISO-8859-1");
        if (!response.startsWith("HTTP/1.1 101") && !response.startsWith("HTTP/1.0 101")) {
            throw new IOException("El televisor no aceptó el enlace WebSocket: " + response.split("\r?\n")[0]);
        }
        String guid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        String expected = Base64.getEncoder().encodeToString(
            MessageDigest.getInstance("SHA-1").digest((key + guid).getBytes(StandardCharsets.US_ASCII)));
        String actual = "";
        for (String line : response.split("\r\n")) {
            int colon = line.indexOf(':');
            if (colon >= 0 && line.substring(0, colon).trim().equalsIgnoreCase("Sec-WebSocket-Accept")) {
                actual = line.substring(colon + 1).trim();
            }
        }
        if (!MessageDigest.isEqual(actual.getBytes(StandardCharsets.US_ASCII), expected.getBytes(StandardCharsets.US_ASCII))) {
            throw new IOException("Error al verificar la negociación WebSocket.");
        }
    }

    public void pairingComplete() throws IOException { socket.setSoTimeout(0); }

    public void sendText(String text) throws IOException {
        writeFrame(0x1, text.getBytes(StandardCharsets.UTF_8));
    }

    private void writeFrame(int opcode, byte[] raw) throws IOException {
        synchronized (sendLock) {
            if (closed) throw new IOException("No hay conexión con el televisor.");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bytes.write(0x80 | opcode);
            int length = raw.length;
            if (length < 126) bytes.write(0x80 | length);
            else if (length <= 65535) {
                bytes.write(0x80 | 126); bytes.write((length >>> 8) & 255); bytes.write(length & 255);
            } else {
                bytes.write(0x80 | 127);
                for (int i = 7; i >= 0; i--) bytes.write((int)(((long) length >>> (8*i)) & 255));
            }
            byte[] mask = new byte[4];
            random.nextBytes(mask);
            bytes.write(mask);
            for (int i = 0; i < length; i++) bytes.write(raw[i] ^ mask[i % 4]);
            out.write(bytes.toByteArray());
            out.flush();
        }
    }

    public void readLoop() {
        String reason = "Conexión finalizada";
        ByteArrayOutputStream fragments = null;
        try {
            while (!closed) {
                int h1 = in.read();
                if (h1 < 0) break;
                int h2 = in.read();
                if (h2 < 0) break;
                boolean fin = (h1 & 0x80) != 0;
                int op = h1 & 0x0f;
                long len = h2 & 127;
                if (len == 126) len = (readByte(in) << 8) | readByte(in);
                if (len == 127) {
                    len = 0;
                    for (int i = 0; i < 8; i++) len = (len << 8) | readByte(in);
                }
                if (len > 1024 * 1024 || len < 0) throw new IOException("Mensaje WebSocket inválido.");
                byte[] mask = (h2 & 0x80) != 0 ? readExact(in, 4) : null;
                byte[] data = readExact(in, (int) len);
                if (mask != null) for (int i = 0; i < data.length; i++) data[i] ^= mask[i % 4];
                if (op == 8) { reason = "El televisor cerró la conexión"; break; }
                if (op == 9) { writeFrame(10, data); continue; }
                if (op == 10) continue;
                if (op == 1 && fin) listener.onMessage(new String(data, StandardCharsets.UTF_8));
                else if (op == 1 && !fin) {
                    fragments = new ByteArrayOutputStream(); fragments.write(data);
                } else if (op == 0 && fragments != null) {
                    fragments.write(data);
                    if (fin) {
                        listener.onMessage(fragments.toString("UTF-8"));
                        fragments = null;
                    }
                }
            }
        } catch (Exception e) {
            if (!closed) reason = "Se perdió la conexión: " + e.getMessage();
        } finally {
            close();
            listener.onClosed(reason);
        }
    }

    private static int readByte(InputStream stream) throws IOException {
        int b = stream.read();
        if (b < 0) throw new EOFException();
        return b;
    }

    private static byte[] readExact(InputStream input, int length) throws IOException {
        byte[] bytes = new byte[length]; int off = 0;
        while (off < length) {
            int count = input.read(bytes, off, length - off);
            if (count < 0) throw new EOFException();
            off += count;
        }
        return bytes;
    }

    public void close() {
        closed = true;
        try { socket.close(); } catch (IOException ignored) { }
    }
}
