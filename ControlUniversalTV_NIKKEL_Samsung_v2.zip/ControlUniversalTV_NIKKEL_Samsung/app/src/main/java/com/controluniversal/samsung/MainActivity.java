package com.controluniversal.samsung;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Native Android app: all TV commands travel from Android directly to the TV
 * using Samsung Tizen's local WebSocket endpoint. No server/cloud account.
 */
public final class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newCachedThreadPool();
    private final ExecutorService commands = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger();
    private WebView web;
    private SharedPreferences prefs;
    private volatile WebSocketTransport transport;
    private volatile AndroidTvRemote androidRemote;
    private volatile String selectedProtocol = "androidtv";
    private final java.util.concurrent.atomic.AtomicInteger scanSequence = new java.util.concurrent.atomic.AtomicInteger();
    private volatile boolean authorized;
    private volatile String currentIp = "";
    private volatile int currentPort = 0;

    private static final Set<String> ALLOWED_KEYS = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(
            "KEY_POWER", "KEY_POWEROFF", "KEY_VOLUP", "KEY_VOLDOWN", "KEY_MUTE",
            "KEY_CHUP", "KEY_CHDOWN", "KEY_CH_LIST",
            "KEY_UP", "KEY_DOWN", "KEY_LEFT", "KEY_RIGHT", "KEY_ENTER", "KEY_RETURN",
            "KEY_HOME", "KEY_MENU", "KEY_SOURCE", "KEY_GUIDE", "KEY_INFO", "KEY_EXIT",
            "KEY_PLAY", "KEY_PAUSE", "KEY_STOP", "KEY_FF", "KEY_REWIND",
            "KEY_RED", "KEY_GREEN", "KEY_YELLOW", "KEY_BLUE",
            "KEY_0", "KEY_1", "KEY_2", "KEY_3", "KEY_4", "KEY_5", "KEY_6", "KEY_7", "KEY_8", "KEY_9"
    )));

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11, 17, 35));
        getWindow().setNavigationBarColor(Color.rgb(11, 17, 35));
        prefs = getSharedPreferences("samsung_remote", MODE_PRIVATE);
        selectedProtocol = prefs.getString("protocol", "androidtv");
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11, 17, 35));
        WebSettings cfg = web.getSettings();
        cfg.setJavaScriptEnabled(true);
        cfg.setAllowFileAccess(true);
        cfg.setAllowContentAccess(false);
        cfg.setAllowFileAccessFromFileURLs(false);
        cfg.setAllowUniversalAccessFromFileURLs(false);
        cfg.setDomStorageEnabled(false);
        cfg.setDefaultTextEncodingName("UTF-8");
        cfg.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.addJavascriptInterface(new JsBridge(), "Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) {
        ui.post(() -> {
            if (web != null) web.evaluateJavascript(script, null);
        });
    }

    private static String q(String text) { return JSONObject.quote(text == null ? "" : text); }
    private void report(String state, String detail, String mode) {
        js("window.App.onStatus(" + q(state) + "," + q(detail) + "," + q(mode) + ");");
    }
    private void note(String message) { js("window.App.toast(" + q(message) + ");"); }

    private static boolean isLocalIp(String ip) {
        if (ip == null || !ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return false;
        String[] s = ip.split("\\.");
        int[] n = new int[4];
        for (int i = 0; i < 4; i++) {
            n[i] = Integer.parseInt(s[i]);
            if (n[i] > 255 || s[i].length() > 1 && s[i].charAt(0) == '0') return false;
        }
        return n[0] == 10 || (n[0] == 172 && n[1] >= 16 && n[1] <= 31)
                || (n[0] == 192 && n[1] == 168) || (n[0] == 169 && n[1] == 254)
                || (n[0] == 100 && n[1] >= 64 && n[1] <= 127);
    }

    private void connect(String ip) {
        if ("androidtv".equals(selectedProtocol)) { connectAndroidTv(ip); return; }
        ip = ip == null ? "" : ip.trim();
        if (!isLocalIp(ip)) {
            report("error", "Escribe una dirección IP privada válida de tu televisor.", "");
            return;
        }
        final String tvIp = ip;
        prefs.edit().putString("last_ip", tvIp).apply();
        int myGeneration = generation.incrementAndGet();
        WebSocketTransport previous = transport;
        transport = null;
        authorized = false;
        currentIp = tvIp;
        if (previous != null) previous.close();
        report("connecting", "Conectando con " + tvIp + "…", "");
        network.execute(() -> {
            String lastError = "";
            for (int port : new int[]{8002, 8001}) {
                if (myGeneration != generation.get()) return;
                try {
                    String encodedName = Base64.getEncoder().encodeToString(
                            "Control Universal TV Android".getBytes(StandardCharsets.UTF_8));
                    String token = prefs.getString("token_" + tvIp, "");
                    String path = "/api/v2/channels/samsung.remote.control?name=" + encodedName
                                + (port == 8002 && !token.isEmpty() ? "&token=" + token : "");
                    String pin = prefs.getString("cert_" + tvIp, "");
                    final int chosenPort = port;
                    WebSocketTransport ws = WebSocketTransport.open(tvIp, port, path, pin,
                            new WebSocketTransport.Listener() {
                        @Override public void onMessage(String message) {
                            if (myGeneration != generation.get()) return;
                            receiveTvMessage(message, myGeneration, tvIp, chosenPort);
                        }
                        @Override public void onClosed(String reason) {
                            if (myGeneration != generation.get()) return;
                            authorized = false;
                            transport = null;
                            report("disconnected", reason, "");
                        }
                    });
                    if (myGeneration != generation.get()) { ws.close(); return; }
                    transport = ws;
                    currentPort = port;
                    report("pairing", "Mira el televisor y selecciona PERMITIR cuando aparezca la autorización.",
                           port == 8002 ? "Conexión segura (8002)" : "Red local (8001)");
                    ws.readLoop();
                    return;
                } catch (SecurityException se) {
                    // Never downgrade if a previously trusted TV presents a changed certificate.
                    if (myGeneration == generation.get()) report("error", se.getMessage(), "");
                    return;
                } catch (Exception e) {
                    lastError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                }
            }
            if (myGeneration == generation.get()) {
                report("error", "No se pudo conectar. Comprueba la IP, el Wi-Fi y que el TV esté encendido. Detalle: " + lastError, "");
            }
        });
    }

    /** Pair or reconnect to a Google/Android TV Remote Service over TLS. */
    private void connectAndroidTv(String ip) {
        ip = ip == null ? "" : ip.trim();
        if (!isLocalIp(ip)) {
            report("error", "Escribe la IP local de tu NIKKEL. La encontrarás en Ajustes > Red.", "");
            return;
        }
        disconnect();
        final String tvIp = ip;
        final int myGeneration = generation.get();
        currentIp = tvIp;
        prefs.edit().putString("last_ip", tvIp).apply();
        report("connecting", "Conectando NIKKEL / Android TV en " + tvIp + "…", "TLS (puertos 6466/6467)");
        network.execute(() -> {
            try {
                AndroidTvIdentity identity = new AndroidTvIdentity();
                if (myGeneration != generation.get()) return;
                AndroidTvRemote remote = new AndroidTvRemote(tvIp, identity.tls, identity.cert,
                        new AndroidTvRemote.Events() {
                    @Override public void status(String state, String detail) {
                        if (myGeneration == generation.get()) report(state, detail, "Android TV Remote v2");
                    }
                    @Override public void enterCode() {
                        if (myGeneration == generation.get()) {
                            report("pairing", "Mira la pantalla del NIKKEL. Introduce aquí sus 6 caracteres.", "Emparejamiento seguro");
                            js("window.App.showPairingCode();");
                        }
                    }
                    @Override public void connected() {
                        if (myGeneration != generation.get()) return;
                        String cert = remoteRefFingerprint(myGeneration);
                        if (!cert.isEmpty()) prefs.edit().putString("atv_cert_" + tvIp, cert).apply();
                        report("connected", "NIKKEL / Android TV conectado: " + tvIp, "Conexión segura TLS");
                        js("window.App.hidePairingCode();");
                    }
                    @Override public void lost(String reason) {
                        if (myGeneration == generation.get()) report("disconnected", "Se desconectó el NIKKEL: " + reason, "");
                    }
                });
                androidRemote = remote;
                String pin = prefs.getString("atv_cert_" + tvIp, "");
                if (!pin.isEmpty()) {
                    try {
                        remote.connectPreviouslyPaired(pin);
                        if (myGeneration == generation.get()) network.execute(remote::runReader);
                        return;
                    } catch (SecurityException sec) {
                        report("error", sec.getMessage(), "");
                        return;
                    } catch (Exception reconnectError) {
                        // The TV may have forgotten this client. The user will re-pair via PIN.
                        if (myGeneration != generation.get()) return;
                    }
                }
                remote.beginPairing();
            } catch (Exception e) {
                if (myGeneration == generation.get()) report("error",
                        "No se pudo comunicar con Android TV: " + describeError(e)
                        + ". Comprueba que ambos estén en la misma red y que el TV tenga Android TV Remote Service.", "");
            }
        });
    }

    private String remoteRefFingerprint(int expectedGeneration) {
        AndroidTvRemote remote = androidRemote;
        return expectedGeneration == generation.get() && remote != null ? remote.pairingFingerprint() : "";
    }
    private static String describeError(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }
    private void finishAndroidTvPairing(String code) {
        final AndroidTvRemote remote = androidRemote;
        final int myGeneration = generation.get();
        if (remote == null) { note("Primero pulsa Conectar."); return; }
        network.execute(() -> {
            try {
                remote.finishPairing(code);
                if (myGeneration == generation.get()) network.execute(remote::runReader);
            } catch (Exception e) {
                if (myGeneration == generation.get()) report("pairing", "No se completó la vinculación: " + describeError(e)
                        + ". Revisa el código o vuelve a conectar.", "");
            }
        });
    }

    private static int codeForAndroidTv(String samsungKey) {
        switch(samsungKey) {
            case "KEY_POWER": case "KEY_POWEROFF": return 26;
            case "KEY_VOLUP": return 24; case "KEY_VOLDOWN": return 25;
            case "KEY_MUTE": return 164;
            case "KEY_CHUP": return 166; case "KEY_CHDOWN": return 167;
            case "KEY_CH_LIST": return 256;
            case "KEY_UP": return 19; case "KEY_DOWN": return 20;
            case "KEY_LEFT": return 21; case "KEY_RIGHT": return 22;
            case "KEY_ENTER": return 23; case "KEY_RETURN": return 4;
            case "KEY_HOME": return 3; case "KEY_MENU": return 82;
            case "KEY_SOURCE": return 178; case "KEY_GUIDE": return 172;
            case "KEY_INFO": return 165; case "KEY_EXIT": return 4;
            case "KEY_PLAY": return 126; case "KEY_PAUSE": return 127;
            case "KEY_STOP": return 86; case "KEY_FF": return 90;
            case "KEY_REWIND": return 89;
            case "KEY_RED": return 183; case "KEY_GREEN": return 184;
            case "KEY_YELLOW": return 185; case "KEY_BLUE": return 186;
            default:
                if (samsungKey != null && samsungKey.matches("KEY_[0-9]"))
                    return 7 + Integer.parseInt(samsungKey.substring(4));
                return -1;
        }
    }
    private void sendAndroidTvKey(String key) {
        int code = codeForAndroidTv(key);
        if (code < 0) { note("Esa tecla no está disponible en Android TV."); return; }
        AndroidTvRemote remote = androidRemote;
        if (remote == null || !remote.isReady()) { note("Conecta y vincula primero tu NIKKEL."); return; }
        commands.execute(() -> {
            try {
                remote.sendKey(code);
                ui.post(() -> { if (web != null) web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); });
            } catch (Exception e) { note("No se pudo enviar la tecla: " + describeError(e)); }
        });
    }

    private void scanAndroidTv() {
        final int myScan = scanSequence.incrementAndGet();
        report("discovering", "Buscando televisores Android TV en tu Wi-Fi…", "mDNS");
        final NsdManager nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
        if (nsd == null) { report("error", "El teléfono no admite búsqueda automática. Introduce la IP del NIKKEL.", ""); return; }
        final java.util.Map<String,String> devices = new java.util.concurrent.ConcurrentHashMap<>();
        final NsdManager.DiscoveryListener listener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String type) { }
            @Override public void onStartDiscoveryFailed(String type, int code) {
                report("error", "La búsqueda falló. Introduce la IP del NIKKEL en el campo de conexión.", "");
            }
            @Override public void onStopDiscoveryFailed(String type, int code) { }
            @Override public void onDiscoveryStopped(String type) { }
            @Override public void onServiceLost(NsdServiceInfo service) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                nsd.resolveService(service, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo s, int error) { }
                    @Override public void onServiceResolved(NsdServiceInfo s) {
                        if (s.getHost() == null || myScan != scanSequence.get()) return;
                        String ip=s.getHost().getHostAddress();
                        if (isLocalIp(ip)) devices.put(ip, s.getServiceName());
                    }
                });
            }
        };
        try {
            nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Exception e) {
            report("error", "No se pudo buscar. Escribe la IP del NIKKEL.", ""); return;
        }
        ui.postDelayed(() -> {
            try { nsd.stopServiceDiscovery(listener); } catch (Exception ignored) { }
            if (myScan != scanSequence.get()) return;
            JSONArray found=new JSONArray();
            for (java.util.Map.Entry<String,String> d : devices.entrySet()) {
                try {
                    JSONObject row = new JSONObject();
                    row.put("ip",d.getKey());
                    row.put("name",d.getValue().isEmpty()?"Android TV":d.getValue());
                    row.put("protocol","androidtv");
                    found.put(row);
                } catch (Exception ignored) { }
            }
            js("window.App.onDevices(" + found.toString() + ");");
            if (androidRemote != null && androidRemote.isReady())
                report("connected", "NIKKEL / Android TV conectado: " + currentIp, "TLS");
            else report("disconnected", found.length()==0 ?
                    "No se encontró automáticamente. Escribe la IP del NIKKEL desde Ajustes > Red." :
                    "Selecciona el televisor encontrado para vincularlo.", "");
        }, 5500);
    }

    private void receiveTvMessage(String message, int gen, String ip, int port) {
        try {
            JSONObject obj = new JSONObject(message);
            String event = obj.optString("event", "");
            if ("ms.channel.connect".equals(event)) {
                WebSocketTransport ws = transport;
                if (gen != generation.get() || ws == null) return;
                JSONObject data = obj.optJSONObject("data");
                String token = data != null ? data.optString("token", "") : "";
                SharedPreferences.Editor editor = prefs.edit();
                if (!token.isEmpty()) editor.putString("token_" + ip, token);
                String fingerprint = ws.getTlsFingerprint();
                if (!fingerprint.isEmpty()) editor.putString("cert_" + ip, fingerprint);
                editor.apply();
                authorized = true;
                ws.pairingComplete();
                report("connected", "Samsung conectado: " + ip, port == 8002 ? "Conexión segura (8002)" : "Red local (8001)");
            } else if (event.contains("unauthorized") || event.contains("error") || event.contains("disconnect")) {
                report("error", "El TV no autorizó la conexión. Revisa Administrador de dispositivos externos o vuelve a vincularlo.", "");
                WebSocketTransport ws = transport;
                if (ws != null) ws.close();
            }
        } catch (Exception ignored) { /* Other Samsung events are not control messages. */ }
    }

    private void sendKey(String key) {
        if ("androidtv".equals(selectedProtocol)) { sendAndroidTvKey(key); return; }
        if (!ALLOWED_KEYS.contains(key)) { note("Comando no permitido."); return; }
        WebSocketTransport ws = transport;
        if (!authorized || ws == null) { note("Primero conecta y autoriza el televisor."); return; }
        commands.execute(() -> {
            try {
                JSONObject params = new JSONObject();
                params.put("Cmd", "Click");
                params.put("DataOfCmd", key);
                params.put("Option", "false");
                params.put("TypeOfRemote", "SendRemoteKey");
                JSONObject cmd = new JSONObject();
                cmd.put("method", "ms.remote.control");
                cmd.put("params", params);
                ws.sendText(cmd.toString());
                ui.post(() -> { if (web != null) web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); });
            } catch (Exception e) {
                note("No se pudo enviar el comando: " + e.getMessage());
            }
        });
    }

    private void disconnect() {
        generation.incrementAndGet();
        AndroidTvRemote atv = androidRemote;
        androidRemote = null;
        if (atv != null) atv.close();
        authorized = false;
        WebSocketTransport old = transport;
        transport = null;
        if (old != null) old.close();
        report("disconnected", "Televisor desconectado.", "");
    }

    private void scan() {
        if ("androidtv".equals(selectedProtocol)) { scanAndroidTv(); return; }
        if (!authorized) report("discovering", "Buscando Samsung Smart TV en la red local…", "");
        network.execute(() -> {
            final int scanGeneration = generation.get();
            LinkedHashSet<String> candidates = new LinkedHashSet<>();
            LinkedHashSet<String> samsungAdvertised = new LinkedHashSet<>();
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiManager.MulticastLock lock = null;
            try {
                if (wifi != null) {
                    lock = wifi.createMulticastLock("samsung-tv-ssdp");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
                try (MulticastSocket socket = new MulticastSocket()) {
                    socket.setTimeToLive(2);
                    socket.setSoTimeout(350);
                    InetAddress group = InetAddress.getByName("239.255.255.250");
                    for (String st : new String[]{"ssdp:all", "urn:schemas-upnp-org:device:MediaRenderer:1"}) {
                        String request = "M-SEARCH * HTTP/1.1\r\n"
                                + "HOST: 239.255.255.250:1900\r\n"
                                + "MAN: \"ssdp:discover\"\r\n"
                                + "MX: 2\r\nST: " + st + "\r\n\r\n";
                        byte[] content = request.getBytes(StandardCharsets.US_ASCII);
                        socket.send(new DatagramPacket(content, content.length, group, 1900));
                    }
                    long end = System.currentTimeMillis() + 4200;
                    while (System.currentTimeMillis() < end && candidates.size() < 24) {
                        byte[] buffer = new byte[4096];
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                        try {
                            socket.receive(packet);
                            String body = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                            String found = packet.getAddress().getHostAddress();
                            if (isLocalIp(found) && (body.contains("samsung") || body.contains("mediarenderer")
                                    || body.contains("upnp:rootdevice"))) {
                                candidates.add(found);
                                if (body.contains("samsung")) samsungAdvertised.add(found);
                            }
                        } catch (java.net.SocketTimeoutException ignored) { }
                    }
                }
            } catch (Exception e) {
                note("La búsqueda automática no está disponible: " + e.getMessage());
            } finally {
                if (lock != null && lock.isHeld()) lock.release();
            }
            JSONArray devices = new JSONArray();
            for (String candidate : candidates) {
                try {
                    String label = probeSamsung(candidate);
                    if (label == null && samsungAdvertised.contains(candidate)) label = "Samsung Smart TV";
                    if (label != null) {
                        JSONObject device = new JSONObject();
                        device.put("ip", candidate);
                        device.put("name", label);
                        devices.put(device);
                    }
                } catch (Exception ignored) { }
            }
            js("window.App.onDevices(" + devices.toString() + ");");
            if (scanGeneration == generation.get()) {
                if (authorized && transport != null) {
                    report("connected", "Samsung conectado: " + currentIp,
                            currentPort == 8002 ? "Conexión segura (8002)" : "Red local (8001)");
                } else {
                    report("disconnected", devices.length() == 0 ?
                            "No se detectó automáticamente. Puedes escribir la IP del televisor." :
                            "Selecciona tu televisor para vincularlo.", "");
                }
            }
        });
    }

    private String probeSamsung(String ip) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL("http://" + ip + ":8001/api/v2/").openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(600);
            conn.setReadTimeout(600);
            if (conn.getResponseCode() != 200) return null;
            StringBuilder b = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null && b.length() < 10000) b.append(line);
            }
            JSONObject payload = new JSONObject(b.toString());
            JSONObject device = payload.optJSONObject("device");
            String model = device != null ? device.optString("modelName", "") : "";
            String name = device != null ? device.optString("name", "") : "";
            String body = b.toString().toLowerCase(Locale.ROOT);
            if (!body.contains("samsung") && !body.contains("tizen") && model.isEmpty()) return null;
            return !name.isEmpty() ? name + (model.isEmpty() ? "" : " · " + model) :
                    "Samsung TV" + (model.isEmpty() ? "" : " · " + model);
        } catch (Exception ignored) { return null; }
        finally { if (conn != null) conn.disconnect(); }
    }

    private void wake(String macAddress) {
        if (macAddress == null || !macAddress.matches("(?i)[0-9a-f]{2}([:-][0-9a-f]{2}){5}")) {
            note("Guarda una dirección MAC válida del televisor (ejemplo: AA:BB:CC:11:22:33).");
            return;
        }
        final String mac = macAddress.toUpperCase(Locale.ROOT).replace('-', ':');
        prefs.edit().putString("mac", mac).apply();
        network.execute(() -> {
            try {
                String hex = mac.replace(":", "");
                byte[] macBytes = new byte[6];
                for (int i = 0; i < 6; i++) macBytes[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
                ByteArrayOutputStream packet = new ByteArrayOutputStream();
                for (int i = 0; i < 6; i++) packet.write(0xff);
                for (int i = 0; i < 16; i++) packet.write(macBytes);
                byte[] payload = packet.toByteArray();
                try (DatagramSocket socket = new DatagramSocket()) {
                    socket.setBroadcast(true);
                    socket.send(new DatagramPacket(payload, payload.length, InetAddress.getByName("255.255.255.255"), 9));
                }
                note("Se envió la señal de encendido. El TV debe admitir Wake-on-LAN.");
            } catch (Exception e) {
                note("No se pudo enviar Wake-on-LAN: " + e.getMessage());
            }
        });
    }

    private class JsBridge {
        @JavascriptInterface public String getConfig() {
            JSONObject o = new JSONObject();
            try {
                o.put("ip", prefs.getString("last_ip", ""));
                o.put("protocol", prefs.getString("protocol", "androidtv"));
                o.put("mac", prefs.getString("mac", ""));
            } catch (Exception ignored) { }
            return o.toString();
        }
        @JavascriptInterface public void connect(String ip) { MainActivity.this.connect(ip); }
        @JavascriptInterface public void disconnect() { MainActivity.this.disconnect(); }
        @JavascriptInterface public void scan() { MainActivity.this.scan(); }
        @JavascriptInterface public void selectProtocol(String protocol) {
            if (!"samsung".equals(protocol) && !"androidtv".equals(protocol)) return;
            scanSequence.incrementAndGet();
            MainActivity.this.disconnect();
            selectedProtocol = protocol;
            prefs.edit().putString("protocol", protocol).apply();
        }
        @JavascriptInterface public void enterPairingCode(String code) { MainActivity.this.finishAndroidTvPairing(code); }
        @JavascriptInterface public void key(String key) { MainActivity.this.sendKey(key); }
        @JavascriptInterface public void wake(String mac) { MainActivity.this.wake(mac); }
        @JavascriptInterface public void saveMac(String mac) {
            mac = mac == null ? "" : mac.trim();
            if (mac.isEmpty() || mac.matches("(?i)[0-9a-f]{2}([:-][0-9a-f]{2}){5}")) {
                prefs.edit().putString("mac", mac).apply();
                note("Configuración guardada.");
            } else note("La dirección MAC no tiene el formato esperado.");
        }
        @JavascriptInterface public void resetPairing() {
            String ip = prefs.getString("last_ip", "");
            if ("androidtv".equals(selectedProtocol)) {
                prefs.edit().remove("atv_cert_" + ip).apply();
                MainActivity.this.disconnect();
                note("Vinculación Android TV borrada. Vuelve a conectar y escribe el nuevo código.");
                return;
            }
            prefs.edit().remove("token_" + ip).remove("cert_" + ip).apply();
            MainActivity.this.disconnect();
            note("Vinculación eliminada para " + ip + ". Conecta de nuevo y acepta en el TV.");
        }
    }

    @Override public void onBackPressed() {
        if ("androidtv".equals(selectedProtocol) && androidRemote != null && androidRemote.isReady()) sendKey("KEY_RETURN");
        else if (authorized) sendKey("KEY_RETURN");
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        generation.incrementAndGet();
        WebSocketTransport ws = transport;
        transport = null;
        if (ws != null) ws.close();
        AndroidTvRemote atv = androidRemote;
        androidRemote = null;
        if (atv != null) atv.close();
        network.shutdownNow();
        commands.shutdownNow();
        if (web != null) {
            web.removeJavascriptInterface("Native");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
