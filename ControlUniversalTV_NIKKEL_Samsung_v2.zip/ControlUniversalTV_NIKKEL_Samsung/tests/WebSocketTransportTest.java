package com.controluniversal.samsung;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Standalone transport test: javac + java, no Android SDK needed. */
public final class WebSocketTransportTest {
    public static void main(String[] args) throws Exception {
        AtomicReference<String> seenCommand = new AtomicReference<>("");
        AtomicReference<String> seenEvent = new AtomicReference<>("");
        CountDownLatch latch = new CountDownLatch(2);
        try (ServerSocket server = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) {
            Thread mock = new Thread(() -> {
                try (Socket socket = server.accept()) {
                    socket.setSoTimeout(7000);
                    InputStream in = socket.getInputStream();
                    OutputStream out = socket.getOutputStream();
                    ByteArrayOutputStream headers = new ByteArrayOutputStream();
                    int a=0,b=0,c=0,d;
                    while ((d=in.read())!=-1) {
                        headers.write(d);
                        if (a=='\r'&&b=='\n'&&c=='\r'&&d=='\n') break;
                        a=b;b=c;c=d;
                    }
                    String request=headers.toString("US-ASCII");
                    String key="";
                    for(String line:request.split("\r\n")) if(line.toLowerCase().startsWith("sec-websocket-key:")) key=line.substring(line.indexOf(':')+1).trim();
                    String accept=Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest(
                            (key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                    out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+accept+"\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    byte[] welcome = "{\"event\":\"ms.channel.connect\",\"data\":{\"token\":\"1234\"}}".getBytes(StandardCharsets.UTF_8);
                    out.write(0x81);out.write(welcome.length);out.write(welcome);out.flush();
                    int h1=in.read(), h2=in.read();
                    if ((h1&15)!=1 || (h2&128)==0) throw new IllegalStateException("El cliente no enmascaró el mensaje");
                    int length=h2&127;
                    if(length==126)length=(in.read()<<8)|in.read();
                    byte[] mask=in.readNBytes(4);
                    byte[] payload=in.readNBytes(length);
                    for (int i=0;i<length;i++) payload[i]^=mask[i%4];
                    seenCommand.set(new String(payload,StandardCharsets.UTF_8));
                    latch.countDown();
                    // Server closes politely.
                    out.write(new byte[]{(byte)0x88,0x00});out.flush();
                } catch (Exception e) { throw new RuntimeException(e); }
            },"mock-samsung-tv");
            mock.start();
            WebSocketTransport conn=WebSocketTransport.open("127.0.0.1",server.getLocalPort(),"/api/v2/channels/samsung.remote.control?name=Test","",
                    new WebSocketTransport.Listener() {
                        @Override public void onMessage(String json) { seenEvent.set(json); latch.countDown(); }
                        @Override public void onClosed(String reason) { }
                    });
            Thread reader=new Thread(conn::readLoop,"mock-client-reader");
            reader.start();
            conn.sendText("{\"method\":\"ms.remote.control\",\"key\":\"KEY_VOLUP\"}");
            if (!latch.await(6,TimeUnit.SECONDS)) throw new AssertionError("No se intercambiaron los mensajes");
            if (!seenEvent.get().contains("1234"))throw new AssertionError("No se recibió token");
            if (!seenCommand.get().contains("KEY_VOLUP"))throw new AssertionError("No se envió comando");
            conn.close();
            reader.join(2000);mock.join(2000);
        }
        System.out.println("OK: handshake RFC 6455, recepción de token, envío enmascarado y cierre.");
    }
}
