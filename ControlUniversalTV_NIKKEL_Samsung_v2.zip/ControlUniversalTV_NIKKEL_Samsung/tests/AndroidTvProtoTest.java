package com.controluniversal.samsung;
import java.io.*;
import java.util.*;
/** Run with javac + java on any JDK 17; no Android SDK required. */
public class AndroidTvProtoTest {
  public static void main(String[] args) throws Exception {
    for(int n : new int[]{0,1,127,128,16384,65536}) {
      byte[] data=new byte[n];Arrays.fill(data,(byte)0xAB);
      ByteArrayOutputStream b=new ByteArrayOutputStream();
      AndroidTvRemote.Proto.writeFrame(b,data);
      byte[] received=AndroidTvRemote.Proto.readFrame(new ByteArrayInputStream(b.toByteArray()));
      if(!Arrays.equals(data,received))throw new AssertionError("framing "+n);
    }
    byte[] contents=AndroidTvRemote.Proto.concat(
      AndroidTvRemote.Proto.number(1,611),
      AndroidTvRemote.Proto.message(2,AndroidTvRemote.Proto.string(5,"ControlTV")));
    Map<Integer,AndroidTvRemote.Proto.Field> result=AndroidTvRemote.Proto.parse(contents);
    if(AndroidTvRemote.Proto.longValue(result,1)!=611)throw new AssertionError("numbers");
    Map<Integer,AndroidTvRemote.Proto.Field> nested=AndroidTvRemote.Proto.parse(result.get(2).bytes);
    if(!"ControlTV".equals(new String(nested.get(5).bytes,"UTF-8")))throw new AssertionError("nested");
    try { AndroidTvRemote.Proto.readFrame(new ByteArrayInputStream(new byte[]{(byte)0x80})); throw new AssertionError("truncation"); }
    catch(EOFException expected) {}
    System.out.println("OK — framing varint, tramas largas, protobuf anidado y EOF");
  }
}
